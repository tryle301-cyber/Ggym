# Gym Tracker (offline)

Home (workouts + schedule), Walk (steps), Recovery, Gym Progress, Habits.
Themes: System / Light / Dark / AMOLED. 120 Hz switch and scroll blur in Settings.

Build: upload gym_tracker.zip to the repo root together with .github/workflows/build.yml.
The workflow unpacks it, generates the Android project, patches it with tool/prepare.sh and builds the APK.
