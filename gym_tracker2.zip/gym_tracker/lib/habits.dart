import 'package:flutter/material.dart';
import 'data.dart';
import 'ui.dart';

const habitColors = [0xFFE07BFF, 0xFFFF6B6B, 0xFF4DA3FF, 0xFF2ECC71, 0xFFFFB300, 0xFF26C6DA, 0xFFFF8A65, 0xFF9CCC65];
const habitIcons = <IconData>[
  Icons.monitor_heart_outlined, Icons.water_drop_outlined, Icons.menu_book_outlined, Icons.self_improvement,
  Icons.directions_run, Icons.code, Icons.bedtime_outlined, Icons.restaurant_outlined,
  Icons.school_outlined, Icons.savings_outlined, Icons.brush_outlined, Icons.music_note_outlined,
];

Widget habitIconBox(Habit h, {double size = 46}) => Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: Color(h.color).withOpacity(0.2), borderRadius: BorderRadius.circular(size * 0.32)),
      child: Icon(habitIcons[h.icon % habitIcons.length], color: Color(h.color)),
    );

Widget _chip(BuildContext c, IconData i, String t, Color col) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: col.withOpacity(0.16), borderRadius: BorderRadius.circular(16)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(i, size: 16, color: col),
        const SizedBox(width: 6),
        Text(t, style: TextStyle(color: col, fontWeight: FontWeight.w700, fontSize: 13)),
      ]),
    );

Future<void> editHabit(BuildContext context, Habit? h) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => HabitEditor(h),
    );

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.today;
        return ScreenFrame(
          title: 'Habits',
          subtitle: 'Track anything, one tap a day',
          actions: [IconButton.filled(icon: const Icon(Icons.add), onPressed: () => editHabit(context, null))],
          children: [
            if (store.habits.isEmpty)
              Panel(child: Text('No habits yet. Tap + to add your first one.', style: TextStyle(color: subtleOf(context)))),
            for (final h in store.habits)
              Panel(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HabitDetail(h.id))),
                child: Column(children: [
                  Row(children: [
                    habitIconBox(h),
                    const SizedBox(width: 12),
                    Expanded(child: Text(h.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
                    IconButton.filled(
                      style: h.done(t)
                          ? IconButton.styleFrom(backgroundColor: Color(h.color), foregroundColor: Colors.black)
                          : IconButton.styleFrom(backgroundColor: fieldOf(context), foregroundColor: subtleOf(context)),
                      icon: const Icon(Icons.check),
                      onPressed: () => store.toggleHabit(h, t),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  HeatGrid(checks: h.checks, color: Color(h.color), weeks: 16, today: t),
                  const SizedBox(height: 14),
                  Row(children: [
                    _chip(context, Icons.local_fire_department_outlined, '${h.current(t)}', Color(h.color)),
                    const SizedBox(width: 8),
                    _chip(context, Icons.track_changes, h.goal > 0 ? 'Goal ${h.goal} days' : 'No streak goal', Color(h.color)),
                  ]),
                ]),
              ),
          ],
        );
      },
    );
  }
}

class HabitDetail extends StatefulWidget {
  final String id;
  const HabitDetail(this.id, {super.key});
  @override
  State<HabitDetail> createState() => _HabitDetailState();
}

class _HabitDetailState extends State<HabitDetail> {
  late DateTime month = DateTime(store.today.year, store.today.month, 1);

  Future<void> _note(Habit h, DateTime d) async {
    final k = dkey(d);
    final ctl = TextEditingController(text: h.notes[k] ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Note · ${niceDate(d)}'),
        content: TextField(controller: ctl, autofocus: true, maxLines: 4, decoration: const InputDecoration(hintText: 'What went well? What got in the way?')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok != true) return;
    if (ctl.text.trim().isEmpty) {
      h.notes.remove(k);
    } else {
      h.notes[k] = ctl.text.trim();
    }
    store.save();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final idx = store.habits.indexWhere((x) => x.id == widget.id);
        if (idx < 0) return const Scaffold(body: Center(child: Text('Habit not found')));
        final h = store.habits[idx];
        final col = Color(h.color);
        final t = store.today;
        final first = DateTime(month.year, month.month, 1);
        final days = DateTime(month.year, month.month + 1, 0).day;
        final lead = first.weekday - 1;
        final monthPrefix = '${month.year}-${month.month.toString().padLeft(2, '0')}';
        final notes = h.notes.entries.where((e) => e.key.startsWith(monthPrefix)).toList()..sort((a, b) => a.key.compareTo(b.key));

        final mo = <double>[], ml = <String>[];
        for (var i = 11; i >= 0; i--) {
          final s = DateTime(t.year, t.month - i, 1);
          final p = '${s.year}-${s.month.toString().padLeft(2, '0')}';
          mo.add(h.checks.where((k) => k.startsWith(p)).length.toDouble());
          ml.add(monthNames[s.month - 1].substring(0, 1));
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(h.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => editHabit(context, h)),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (c) => AlertDialog(
                      title: const Text('Delete habit?'),
                      content: Text('"${h.name}" and all its history will be removed.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
                      ],
                    ),
                  );
                  if (ok == true) {
                    store.habits.removeAt(idx);
                    store.save();
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
            Panel(child: HeatGrid(checks: h.checks, color: col, weeks: 26, today: t)),
            Row(children: [
              _chip(context, Icons.local_fire_department_outlined, '${h.current(t)}', col),
              const SizedBox(width: 8),
              _chip(context, Icons.track_changes, h.goal > 0 ? 'Goal ${h.goal} days' : 'No streak goal', col),
            ]),
            const SizedBox(height: 12),
            Panel(
              child: Column(children: [
                Row(children: [
                  IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1, 1)), icon: const Icon(Icons.chevron_left)),
                  Expanded(child: Center(child: Text('${monthNames[month.month - 1]} ${month.year}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)))),
                  IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1, 1)), icon: const Icon(Icons.chevron_right)),
                ]),
                Row(children: [
                  for (final n in weekdayNames)
                    Expanded(child: Center(child: Text(n.substring(0, 2), style: TextStyle(color: subtleOf(context), fontSize: 12)))),
                ]),
                const SizedBox(height: 4),
                GridView.count(
                  crossAxisCount: 7,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (var i = 0; i < lead; i++) const SizedBox.shrink(),
                    for (var d = 1; d <= days; d++) _cell(h, DateTime(month.year, month.month, d), col),
                  ],
                ),
                Text('Tap a day to tick it. Press and hold to add a note.', style: TextStyle(color: subtleOf(context), fontSize: 12)),
              ]),
            ),
            Panel(
              child: notes.isEmpty
                  ? Text('No notes this month. What went well? What got in the way?', style: TextStyle(color: subtleOf(context)))
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      for (final n in notes)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Text('${pdate(n.key).day} ${monthNames[pdate(n.key).month - 1]}: ${n.value}'),
                        ),
                    ]),
            ),
            Row(children: [
              Expanded(child: _stat(context, '${h.checks.length}', 'Completions')),
              const SizedBox(width: 10),
              Expanded(child: _stat(context, '${h.rate(t).round()}%', 'Completion rate')),
            ]),
            Row(children: [
              Expanded(child: _stat(context, '${h.current(t)}', 'Current streak')),
              const SizedBox(width: 10),
              Expanded(child: _stat(context, '${h.best()}', 'Best streak')),
            ]),
            sectionTitle(context, 'Completions / month'),
            Panel(child: BarChartW(values: mo, labels: ml)),
          ]),
        );
      },
    );
  }

  Widget _stat(BuildContext c, String v, String l) => Panel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          Text(l, style: TextStyle(color: subtleOf(c), fontSize: 12)),
        ]),
      );

  Widget _cell(Habit h, DateTime d, Color col) {
    final k = dkey(d);
    final on = h.checks.contains(k);
    final future = d.isAfter(store.today);
    return GestureDetector(
      onTap: future ? null : () => store.toggleHabit(h, d),
      onLongPress: future ? null : () => _note(h, d),
      child: Container(
        margin: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: on ? col : fieldOf(context),
          borderRadius: BorderRadius.circular(12),
          border: d == store.today ? Border.all(color: col, width: 2) : null,
        ),
        child: Stack(alignment: Alignment.center, children: [
          Text('${d.day}', style: TextStyle(color: on ? Colors.black : (future ? subtleOf(context) : null), fontWeight: FontWeight.w600)),
          if (h.notes.containsKey(k))
            Positioned(bottom: 4, child: Container(width: 5, height: 5, decoration: BoxDecoration(color: on ? Colors.black : col, shape: BoxShape.circle))),
        ]),
      ),
    );
  }
}

class HabitEditor extends StatefulWidget {
  final Habit? h;
  const HabitEditor(this.h, {super.key});
  @override
  State<HabitEditor> createState() => _HabitEditorState();
}

class _HabitEditorState extends State<HabitEditor> {
  late final name = TextEditingController(text: widget.h?.name ?? '');
  late final desc = TextEditingController(text: widget.h?.desc ?? '');
  late int color = widget.h?.color ?? habitColors[0];
  late int icon = widget.h?.icon ?? 0;
  late double goal = (widget.h?.goal ?? 0).toDouble();

  void _save() {
    if (name.text.trim().isEmpty) return;
    final h = widget.h;
    if (h == null) {
      store.habits.add(Habit(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name.text.trim(), desc: desc.text.trim(), color: color, icon: icon,
        goal: goal.toInt(), created: store.todayKey,
      ));
    } else {
      h.name = name.text.trim();
      h.desc = desc.text.trim();
      h.color = color;
      h.icon = icon;
      h.goal = goal.toInt();
    }
    store.save();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.h == null ? 'New habit' : 'Edit habit', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 8),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description (optional)')),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (final c in habitColors)
              GestureDetector(
                onTap: () => setState(() => color = c),
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: color == c ? Colors.white : Colors.transparent, width: 3)),
                ),
              ),
          ]),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (var i = 0; i < habitIcons.length; i++)
              GestureDetector(
                onTap: () => setState(() => icon = i),
                child: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: icon == i ? Color(color).withOpacity(0.25) : fieldOf(context),
                    borderRadius: BorderRadius.circular(14),
                    border: icon == i ? Border.all(color: Color(color), width: 2) : null,
                  ),
                  child: Icon(habitIcons[i], color: icon == i ? Color(color) : subtleOf(context)),
                ),
              ),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            const Expanded(child: Text('Streak goal (days, 0 = none)')),
            SizedBox(width: 140, child: NumStepper(value: goal, step: 1, isInt: true, onChanged: (v) => setState(() => goal = v))),
          ]),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: _save, child: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Save habit')))),
        ]),
      ),
    );
  }
}
