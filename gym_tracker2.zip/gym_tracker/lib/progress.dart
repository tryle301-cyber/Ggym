import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'data.dart';
import 'ui.dart';
import 'gym.dart' show cGreen, cRed;

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});
  @override
  State<ProgressScreen> createState() => _ProgressState();
}

class _ProgressState extends State<ProgressScreen> {
  String? exId;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.today;
        final thisStart = DateTime(t.year, t.month, 1);
        final lastStart = DateTime(t.year, t.month - 1, 1);
        final cur = store.completion(thisStart, t);
        final prev = store.completion(lastStart, DateTime(t.year, t.month, 0));

        final ids = store.lib.values
            .where((e) => store.sessions.any((s) => s.sets.any((x) => x.ex == e.id && !x.warm)))
            .toList()
          ..sort((a, b) => a.name.compareTo(b.name));
        if (exId == null || !ids.any((e) => e.id == exId)) exId = ids.isEmpty ? null : ids.first.id;

        final tops = <double>[];
        double bestW = 0, bestE = 0;
        String bestSet = '-';
        if (exId != null) {
          for (final s in store.sessions) {
            final ws = s.sets.where((x) => x.ex == exId && !x.warm).toList();
            if (ws.isEmpty) continue;
            tops.add(ws.map((x) => x.w).reduce(math.max));
            for (final x in ws) {
              if (x.w > bestW) bestW = x.w;
              if (e1rm(x.w, x.r) > bestE) {
                bestE = e1rm(x.w, x.r);
                bestSet = '${fmt(x.w)} kg × ${x.r}';
              }
            }
          }
        }

        final mon = mondayOf(t);
        final vols = <double>[], vl = <String>[];
        for (var i = 7; i >= 0; i--) {
          final m = addDays(mon, -7 * i);
          final a = dkey(m), b = dkey(addDays(m, 7));
          var v = 0.0;
          for (final s in store.sessions) {
            if (s.date.compareTo(a) >= 0 && s.date.compareTo(b) < 0) {
              for (final x in s.sets) {
                if (!x.warm) v += x.w * x.r;
              }
            }
          }
          vols.add(v / 1000);
          vl.add('${m.day}');
        }

        final bw = store.body;
        final bwYs = bw.map((e) => (e['kg'] as num).toDouble()).toList();
        final bwShow = bwYs.length > 30 ? bwYs.sublist(bwYs.length - 30) : bwYs;

        return ScreenFrame(
          title: 'Gym Progress',
          subtitle: 'Strength and consistency',
          children: [
            Panel(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CompletionPage())),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Completion this month', style: TextStyle(color: subtleOf(context))),
                    Text('${cur.round()}%', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
                    _delta(cur - prev, 'vs last month'),
                  ]),
                ),
                const Icon(Icons.chevron_right),
              ]),
            ),
            sectionTitle(context, 'Lift progress'),
            Panel(
              child: ids.isEmpty
                  ? Text('Finish a workout to see your lift charts here.', style: TextStyle(color: subtleOf(context)))
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      DropdownButton<String>(
                        isExpanded: true,
                        value: exId,
                        items: [for (final e in ids) DropdownMenuItem(value: e.id, child: Text(e.name))],
                        onChanged: (v) => setState(() => exId = v),
                      ),
                      const SizedBox(height: 8),
                      Text('Top weight per session (kg)', style: TextStyle(color: subtleOf(context), fontSize: 12)),
                      const SizedBox(height: 6),
                      LineChartW(ys: tops),
                      const SizedBox(height: 12),
                      Row(children: [
                        _stat('Best weight', '${fmt(bestW)} kg'),
                        _stat('Best est. 1RM', '${fmt(bestE)} kg'),
                        _stat('Sessions', '${tops.length}'),
                      ]),
                      const SizedBox(height: 8),
                      Text('Best set: $bestSet', style: TextStyle(color: subtleOf(context), fontSize: 12)),
                    ]),
            ),
            sectionTitle(context, 'Weekly volume (tonnes)'),
            Panel(child: BarChartW(values: vols, labels: vl)),
            Row(children: [
              const Expanded(child: Text('Body weight', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
              TextButton.icon(
                onPressed: () async {
                  final last = bwYs.isEmpty ? 70.0 : bwYs.last;
                  final v = await askNumber(context, 'Body weight (kg)', last);
                  if (v != null && v > 0) {
                    store.body.removeWhere((e) => e['d'] == store.todayKey);
                    store.body.add({'d': store.todayKey, 'kg': v});
                    store.body.sort((a, b) => (a['d'] as String).compareTo(b['d'] as String));
                    store.save();
                  }
                },
                icon: const Icon(Icons.add),
                label: const Text('Log'),
              ),
            ]),
            Panel(
              child: bwYs.isEmpty
                  ? Text('No weigh-ins yet. Tap Log to add one.', style: TextStyle(color: subtleOf(context)))
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        Text(fmt(bwYs.last), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
                        Text(' kg', style: TextStyle(color: subtleOf(context))),
                        const Spacer(),
                        if (bwYs.length > 1) _delta(bwYs.last - bwYs.first, 'since first', unit: ' kg', greenUp: false),
                      ]),
                      const SizedBox(height: 8),
                      LineChartW(ys: bwShow, height: 110),
                    ]),
            ),
          ],
        );
      },
    );
  }

  Widget _stat(String l, String v) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text(l, style: TextStyle(color: subtleOf(context), fontSize: 12)),
        ]),
      );
}

Widget _delta(double d, String label, {String unit = '%', bool greenUp = true}) {
  final up = d >= 0;
  final good = greenUp ? up : !up;
  final col = d.abs() < 0.05 ? Colors.grey : (good ? cGreen : cRed);
  return Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(up ? Icons.arrow_upward : Icons.arrow_downward, size: 14, color: col),
    const SizedBox(width: 2),
    Text('${fmt(d.abs())}$unit $label', style: TextStyle(color: col, fontSize: 12, fontWeight: FontWeight.w600)),
  ]);
}

// ================================================================ COMPLETION PAGE
class CompletionPage extends StatelessWidget {
  const CompletionPage({super.key});
  @override
  Widget build(BuildContext context) {
    final t = store.today;
    final thisStart = DateTime(t.year, t.month, 1);
    final lastStart = DateTime(t.year, t.month - 1, 1);
    final cur = store.completion(thisStart, t);
    final prev = store.completion(lastStart, DateTime(t.year, t.month, 0));
    final overall = store.completion(pdate(store.startDate), t);
    final (curStreak, bestStreak) = store.weekStreaks();

    final mon = mondayOf(t);
    final wk = <double>[], wl = <String>[];
    for (var i = 9; i >= 0; i--) {
      final m = addDays(mon, -7 * i);
      wk.add(store.weekCount(m).toDouble());
      wl.add('${m.day}/${m.month}');
    }
    final mo = <double>[], ml = <String>[];
    for (var i = 5; i >= 0; i--) {
      final s = DateTime(t.year, t.month - i, 1);
      final e = DateTime(t.year, t.month - i + 1, 0);
      final a = dkey(s), b = dkey(e);
      mo.add(store.sessions.where((x) => x.date.compareTo(a) >= 0 && x.date.compareTo(b) <= 0).length.toDouble());
      ml.add(monthNames[s.month - 1]);
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Completion', style: TextStyle(fontWeight: FontWeight.w800))),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
        Row(children: [
          _tile(context, 'This month', cur),
          const SizedBox(width: 10),
          _tile(context, 'Last month', prev),
          const SizedBox(width: 10),
          _tile(context, 'Overall', overall),
        ]),
        Panel(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [_delta(cur - prev, 'compared with last month')])),
        Row(children: [
          Expanded(child: _big(context, '$curStreak', 'Week streak')),
          const SizedBox(width: 10),
          Expanded(child: _big(context, '$bestStreak', 'Best week streak')),
        ]),
        sectionTitle(context, 'Workouts per week'),
        Panel(child: BarChartW(values: wk, labels: wl, goal: store.weeklyGoal.toDouble())),
        sectionTitle(context, 'Workouts per month'),
        Panel(child: BarChartW(values: mo, labels: ml)),
        Text(
          'Only planned workout days count. Rest days never lower your score, skipped days do, and a pending workout you finish later counts as done. The weekly goal is ${store.weeklyGoal} sessions (change it in Settings).',
          style: TextStyle(color: subtleOf(context), fontSize: 12),
        ),
      ]),
    );
  }

  Widget _tile(BuildContext c, String l, double v) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardOf(c),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: isDark(c) ? Colors.white10 : Colors.black12),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${v.round()}%', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: accentOf(c))),
            const SizedBox(height: 4),
            Text(l, style: TextStyle(color: subtleOf(c), fontSize: 12)),
          ]),
        ),
      );

  Widget _big(BuildContext c, String v, String l) => Panel(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          Text(l, style: TextStyle(color: subtleOf(c), fontSize: 12)),
        ]),
      );
}
