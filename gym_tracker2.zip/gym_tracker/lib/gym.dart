import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'data.dart';
import 'ui.dart';
import 'settings.dart';

const cRed = Color(0xFFEF5350);
const cAmber = Color(0xFFFFB300);
const cGreen = Color(0xFF2ECC71);
const cBlue = Color(0xFF4DA3FF);

Color recColor(Rec r) {
  if (r.overdue) return cBlue;
  if (r.pct < 50) return cRed;
  if (r.pct < 85) return cAmber;
  return cGreen;
}

Color dayColor(BuildContext c, String s) {
  switch (s) {
    case 'done':
    case 'today':
      return accentOf(c);
    case 'skipped':
      return cRed;
    case 'rest':
      return cBlue;
    case 'moved':
      return cAmber;
    default:
      return subtleOf(c);
  }
}

IconData dayIcon(String s) {
  switch (s) {
    case 'done':
      return Icons.check;
    case 'skipped':
      return Icons.close;
    case 'rest':
      return Icons.bedtime_outlined;
    case 'moved':
      return Icons.swap_horiz;
    case 'today':
      return Icons.bolt;
    default:
      return Icons.circle_outlined;
  }
}

void openWorkout(BuildContext c, String wid) =>
    Navigator.push(c, MaterialPageRoute(builder: (_) => SessionScreen(wid)));

Future<void> showSkipSheet(BuildContext context) async {
  final wid = store.planned(store.today);
  if (wid == 'REST') return;
  const opts = [
    ('rest', 'Move to next rest day', 'The rest of the week stays the same'),
    ('shift', 'Do it tomorrow', 'Following workouts shift one day and use up your next rest day'),
    ('swap', 'Swap with tomorrow', 'Today and tomorrow trade places'),
    ('pending', 'Keep as pending', 'The app suggests it when the muscles are recovered'),
    ('drop', 'Drop it', 'Mark as skipped, no rescheduling'),
  ];
  final mode = await showModalBottomSheet<String>(
    context: context,
    builder: (c) => SafeArea(
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Skip ${nameOf(wid)}?', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ),
          for (final o in opts) ListTile(title: Text(o.$2), subtitle: Text(o.$3), onTap: () => Navigator.pop(c, o.$1)),
        ]),
      ),
    ),
  );
  if (mode == null) return;
  final err = store.skipToday(mode);
  if (err != null && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
  }
}

// ================================================================ HOME
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.today;
        final p = store.planned(t);
        final ranks = store.ranking();
        final top = ranks.first;
        final doneToday = store.sessions.any((s) => s.date == store.todayKey);
        final skippedToday = store.skips.any((s) => s.date == store.todayKey);
        final pend = store.pendingList();
        final mon = mondayOf(t);
        final weekDone = store.weekCount(mon);
        final accent = accentOf(context);

        String label;
        if (top.w.id == p && !skippedToday) {
          label = "TODAY'S WORKOUT";
        } else if (p == 'REST') {
          label = 'OPTIONAL TRAINING';
        } else {
          label = 'BEST OPTION RIGHT NOW';
        }
        final others = doneToday ? ranks : ranks.skip(1).toList();

        return ScreenFrame(
          title: 'Train',
          subtitle: niceDate(t),
          actions: [
            IconButton.filledTonal(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
          children: [
            Panel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('This week', style: TextStyle(color: subtleOf(context))),
                const SizedBox(height: 4),
                Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('$weekDone', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800)),
                  Text('  / ${store.weeklyGoal} sessions', style: TextStyle(color: subtleOf(context), fontSize: 16)),
                ]),
                const SizedBox(height: 14),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  for (var i = 0; i < 7; i++) _dayDot(context, addDays(mon, i)),
                ]),
              ]),
            ),
            Row(children: [
              _statBox(context, '${store.sessions.where((x) => x.date.compareTo(dkey(addDays(t, -6))) >= 0).length}', 'Last 7 days'),
              const SizedBox(width: 10),
              _statBox(context, '${store.sessions.where((x) => x.date.startsWith('${t.year}-${t.month.toString().padLeft(2, '0')}')).length}', 'This month'),
              const SizedBox(width: 10),
              _statBox(context, '${store.sessions.where((x) => x.date.startsWith('${t.year}-')).length}', 'This year'),
            ]),
            const SizedBox(height: 12),
            for (final s in pend)
              Panel(
                color: cAmber.withOpacity(0.12),
                child: Row(children: [
                  const Icon(Icons.history, color: cAmber),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(nameOf(s.wid), style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('Missed ${niceDate(pdate(s.date))}', style: TextStyle(color: subtleOf(context), fontSize: 12)),
                    ]),
                  ),
                  TextButton(onPressed: () => store.dropPending(s), child: const Text('Drop')),
                  FilledButton.tonal(onPressed: () => openWorkout(context, s.wid), child: const Text('Do it now')),
                ]),
              ),
            if (doneToday)
              const Panel(
                child: Row(children: [
                  Icon(Icons.check_circle, color: cGreen),
                  SizedBox(width: 12),
                  Expanded(child: Text('Workout done today. Nice work!', style: TextStyle(fontWeight: FontWeight.w700))),
                ]),
              )
            else ...[
              if (p == 'REST')
                Panel(
                  child: Row(children: [
                    const Icon(Icons.bedtime_outlined, color: cBlue),
                    const SizedBox(width: 12),
                    Expanded(child: Text('Planned rest day. Feeling good? Training is optional.', style: TextStyle(color: subtleOf(context)))),
                  ]),
                ),
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  gradient: LinearGradient(colors: [accent, Color.lerp(accent, Colors.indigo, 0.55)!]),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 12)),
                  const SizedBox(height: 6),
                  Text(top.w.name, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(top.reason, style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 16),
                  Row(children: [
                    FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black),
                      onPressed: () => openWorkout(context, top.w.id),
                      child: const Text('Start workout'),
                    ),
                    const SizedBox(width: 8),
                    if (label == "TODAY'S WORKOUT")
                      TextButton(
                        style: TextButton.styleFrom(foregroundColor: Colors.white),
                        onPressed: () => showSkipSheet(context),
                        child: const Text('Skip'),
                      ),
                  ]),
                ]),
              ),
            ],
            sectionTitle(context, 'Other workouts'),
            for (final r in others)
              Panel(
                onTap: () => openWorkout(context, r.w.id),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(r.w.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      const SizedBox(height: 2),
                      Text(r.reason, style: TextStyle(color: subtleOf(context), fontSize: 12)),
                    ]),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: _avgColor(r.avg).withOpacity(0.18),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text('${r.avg.round()}% ready', style: TextStyle(color: _avgColor(r.avg), fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ]),
              ),
            ...scheduleSection(context),
          ],
        );
      },
    );
  }

  Widget _statBox(BuildContext c, String v, String l) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          decoration: BoxDecoration(
            color: cardOf(c),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: isDark(c) ? Colors.white10 : Colors.black12),
          ),
          child: Column(children: [
            Text(v, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(l, style: TextStyle(color: subtleOf(c), fontSize: 11)),
          ]),
        ),
      );

  Color _avgColor(double v) => v < 50 ? cRed : (v < 85 ? cAmber : cGreen);

  Widget _dayDot(BuildContext c, DateTime d) {
    final st = store.dayStatus(d);
    final col = dayColor(c, st);
    final filled = st == 'done';
    return Column(children: [
      Text(weekdayNames[d.weekday - 1].substring(0, 1), style: TextStyle(color: subtleOf(c), fontSize: 12)),
      const SizedBox(height: 6),
      Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: filled ? col : Colors.transparent,
          border: Border.all(color: col.withOpacity(st == 'planned' ? 0.35 : 1), width: st == 'today' ? 2.5 : 1.5),
        ),
        child: Icon(dayIcon(st), size: 17, color: filled ? Theme.of(c).colorScheme.onPrimary : col),
      ),
    ]);
  }
}

// ================================================================ SESSION
class SRow {
  double w;
  int r;
  bool done, warm;
  SRow(this.w, this.r, [this.done = false, this.warm = false]);
}

class SessionScreen extends StatefulWidget {
  final String wid;
  const SessionScreen(this.wid, {super.key});
  @override
  State<SessionScreen> createState() => _SessionState();
}

class _SessionState extends State<SessionScreen> {
  final Map<String, List<SRow>> rows = {};
  final Map<String, Goal> goals = {};
  Timer? timer;
  int rest = 0;
  late DateTime started;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    started = DateTime.now();
    final d = store.draft;
    final restore = d != null && d['wid'] == widget.wid && d['date'] == store.todayKey;
    if (restore) started = DateTime.fromMillisecondsSinceEpoch(d!['start'] as int);
    for (final id in store.template[widget.wid] ?? <String>[]) {
      final e = store.lib[id];
      if (e == null) continue;
      goals[id] = store.goalFor(e);
      final saved = restore ? (d!['rows'] as Map)[id] : null;
      if (saved != null) {
        rows[id] = (saved as List)
            .map((x) => SRow((x['w'] as num).toDouble(), x['r'] as int, x['d'] == true, x['m'] == true))
            .toList();
      } else {
        final g = goals[id]!;
        rows[id] = List.generate(e.sets, (_) => SRow(g.w, g.r));
      }
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    WakelockPlus.disable();
    super.dispose();
  }

  void _persist() {
    store.draft = {
      'wid': widget.wid,
      'date': store.todayKey,
      'start': started.millisecondsSinceEpoch,
      'rows': {
        for (final en in rows.entries)
          en.key: [for (final r in en.value) {'w': r.w, 'r': r.r, 'd': r.done, 'm': r.warm}]
      },
    };
    store.saveQuiet();
  }

  void _ch(VoidCallback f) {
    setState(f);
    _persist();
  }

  void _startRest() {
    timer?.cancel();
    setState(() => rest = store.restSecs);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => rest--);
      if (rest <= 0) {
        t.cancel();
        HapticFeedback.heavyImpact();
      }
    });
  }

  void _stopRest() {
    timer?.cancel();
    setState(() => rest = 0);
  }

  Future<void> _finish() async {
    final sets = <SetLog>[];
    for (final id in store.template[widget.wid] ?? <String>[]) {
      for (final r in rows[id] ?? <SRow>[]) {
        if (r.done) sets.add(SetLog(id, r.w, r.r, r.warm));
      }
    }
    if (sets.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tick at least one set first.')));
      return;
    }
    final now = DateTime.now();
    final s = Session(now.millisecondsSinceEpoch, store.todayKey, widget.wid, now.millisecondsSinceEpoch,
        now.difference(started).inMinutes, sets);
    final prs = store.finishSession(s);
    final vol = sets.where((x) => !x.warm).fold<double>(0, (a, x) => a + x.w * x.r);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Workout saved'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${sets.where((x) => !x.warm).length} working sets · ${fmt(vol)} kg volume · ${s.mins} min'),
          const SizedBox(height: 12),
          if (prs.isEmpty) const Text('No new records this time. Keep pushing.'),
          for (final p in prs) Text('🏆 $p'),
        ]),
        actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('Done'))],
      ),
    );
    if (mounted) Navigator.pop(context);
  }

  Future<void> _addEx() async {
    final ids = store.template[widget.wid]!;
    final avail = store.lib.values.where((e) => !ids.contains(e.id)).toList()
      ..sort((a, b) => a.name.compareTo(b.name));
    final picked = await showDialog<Ex>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Add exercise'),
        content: SizedBox(
          width: double.maxFinite,
          height: 380,
          child: ListView(children: [
            for (final e in avail)
              ListTile(title: Text(e.name), subtitle: Text(cap(e.muscle)), onTap: () => Navigator.pop(c, e)),
          ]),
        ),
      ),
    );
    if (picked == null) return;
    ids.add(picked.id);
    goals[picked.id] = store.goalFor(picked);
    final g = goals[picked.id]!;
    rows[picked.id] = List.generate(picked.sets, (_) => SRow(g.w, g.r));
    setState(() {});
    _persist();
    store.save();
  }

  Future<void> _menu(String v, Ex e) async {
    if (v == 'tip') {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(title: Text(e.name), content: Text(e.tip.isEmpty ? 'No tip yet.' : e.tip)),
      );
    } else if (v == 'step') {
      final n = await askNumber(context, 'Smallest weight jump (kg)', e.inc);
      if (n != null && n > 0) {
        e.inc = n;
        goals[e.id] = store.goalFor(e);
        setState(() {});
        store.save();
      }
    } else if (v == 'remove') {
      store.template[widget.wid]!.remove(e.id);
      rows.remove(e.id);
      setState(() {});
      _persist();
      store.save();
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = wkOf(widget.wid);
    final ids = store.template[widget.wid] ?? <String>[];
    return Scaffold(
      appBar: AppBar(
        title: Text(w.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(icon: const Icon(Icons.add), tooltip: 'Add exercise', onPressed: _addEx)],
      ),
      body: Column(children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 16), children: [
            for (final id in ids)
              if (store.lib[id] != null && rows[id] != null) _exCard(store.lib[id]!),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: _finish,
              icon: const Icon(Icons.flag),
              label: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Finish workout')),
            ),
          ]),
        ),
        if (rest > 0)
          Container(
            color: cardOf(context),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SafeArea(
              top: false,
              child: Row(children: [
                const Icon(Icons.timer_outlined),
                const SizedBox(width: 8),
                Text('Rest ${rest ~/ 60}:${(rest % 60).toString().padLeft(2, '0')}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                const Spacer(),
                TextButton(onPressed: () => setState(() => rest += 15), child: const Text('+15s')),
                TextButton(onPressed: _stopRest, child: const Text('Skip')),
              ]),
            ),
          ),
      ]),
    );
  }

  Widget _exCard(Ex e) {
    final g = goals[e.id]!;
    final rs = rows[e.id]!;
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(e.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              Text('${cap(e.muscle)} · ${e.sets} × ${e.repMin}-${e.repMax}', style: TextStyle(color: subtleOf(context), fontSize: 12)),
            ]),
          ),
          PopupMenuButton<String>(
            onSelected: (v) => _menu(v, e),
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'tip', child: Text('Form tip')),
              PopupMenuItem(value: 'step', child: Text('Weight step (${fmt(e.inc)} kg)')),
              const PopupMenuItem(value: 'remove', child: Text('Remove from workout')),
            ],
          ),
        ]),
        const SizedBox(height: 8),
        Text('Last: ${g.last}', style: TextStyle(color: subtleOf(context), fontSize: 13)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: accentOf(context).withOpacity(0.14), borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Icon(Icons.flag_outlined, size: 18, color: accentOf(context)),
            const SizedBox(width: 8),
            Expanded(child: Text(g.text, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
          ]),
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < rs.length; i++) _setRow(e, rs, i),
        Row(children: [
          TextButton.icon(
            onPressed: () => _ch(() => rs.add(SRow(rs.isEmpty ? g.w : rs.last.w, rs.isEmpty ? g.r : rs.last.r))),
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Add set'),
          ),
          if (rs.length > 1) TextButton(onPressed: () => _ch(() => rs.removeLast()), child: const Text('Remove set')),
        ]),
      ]),
    );
  }

  Widget _setRow(Ex e, List<SRow> rs, int i) {
    final r = rs[i];
    final n = rs.take(i + 1).where((x) => !x.warm).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        GestureDetector(
          onTap: () => _ch(() => r.warm = !r.warm),
          child: SizedBox(
            width: 28,
            child: Text(r.warm ? 'W' : '$n',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w800, color: r.warm ? cAmber : subtleOf(context))),
          ),
        ),
        Expanded(flex: 5, child: NumStepper(value: r.w, step: e.inc, suffix: ' kg', onChanged: (v) => _ch(() => r.w = v))),
        const SizedBox(width: 8),
        Expanded(
          flex: 4,
          child: NumStepper(value: r.r.toDouble(), step: 1, isInt: true, suffix: ' reps', onChanged: (v) => _ch(() => r.r = v.toInt())),
        ),
        const SizedBox(width: 8),
        IconButton.filled(
          style: r.done ? IconButton.styleFrom(backgroundColor: cGreen, foregroundColor: Colors.white) : IconButton.styleFrom(backgroundColor: fieldOf(context), foregroundColor: subtleOf(context)),
          onPressed: () {
            _ch(() => r.done = !r.done);
            if (r.done && !r.warm) _startRest();
          },
          icon: const Icon(Icons.check),
        ),
      ]),
    );
  }
}

// ================================================================ SCHEDULE (shown inside Home)
List<Widget> scheduleSection(BuildContext context) {
  final t = store.today;
  final mon = mondayOf(t);
  final p = store.planned(t);
  final canSkip = p != 'REST' &&
      !store.sessions.any((s) => s.date == store.todayKey) &&
      !store.skips.any((s) => s.date == store.todayKey);
  return [
    sectionTitle(context, 'Schedule · this week'),
    Panel(child: Column(children: [for (var i = 0; i < 7; i++) _schedRow(context, addDays(mon, i))])),
    Row(children: [
      if (canSkip)
        Expanded(
          child: FilledButton.tonalIcon(
            onPressed: () => showSkipSheet(context),
            icon: const Icon(Icons.skip_next),
            label: const Text('Skip today'),
          ),
        ),
      if (canSkip) const SizedBox(width: 8),
      Expanded(
        child: OutlinedButton.icon(
          onPressed: store.resetWeek,
          icon: const Icon(Icons.restart_alt),
          label: const Text('Reset week'),
        ),
      ),
    ]),
    const SizedBox(height: 8),
    Text('Pending workouts expire after 7 days. At most 3 are kept; the oldest becomes missed.',
        style: TextStyle(color: subtleOf(context), fontSize: 12)),
    sectionTitle(context, 'Fixed weekly template'),
    Panel(
      child: Column(children: [
        for (final w in workouts)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(children: [
              SizedBox(width: 48, child: Text(weekdayNames[w.weekday - 1], style: TextStyle(color: subtleOf(context)))),
              Expanded(child: Text(w.name)),
            ]),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            SizedBox(width: 48, child: Text('Sun', style: TextStyle(color: subtleOf(context)))),
            const Expanded(child: Text('Rest')),
          ]),
        ),
      ]),
    ),
  ];
}

Widget _schedRow(BuildContext c, DateTime d) {
  final st = store.dayStatus(d);
  final col = dayColor(c, st);
  final p = store.planned(d);
  final isToday = d == store.today;
  const labels = {
    'done': 'Done', 'skipped': 'Skipped', 'rest': 'Rest day', 'moved': 'Moved here', 'today': 'Today', 'planned': 'Planned'
  };
  return ListTile(
    contentPadding: EdgeInsets.zero,
    leading: CircleAvatar(backgroundColor: col.withOpacity(0.18), child: Icon(dayIcon(st), color: col, size: 20)),
    title: Text('${weekdayNames[d.weekday - 1]} ${d.day} · ${nameOf(p)}',
        style: TextStyle(fontWeight: isToday ? FontWeight.w800 : FontWeight.w500)),
    subtitle: Text(labels[st] ?? '', style: TextStyle(color: col)),
    trailing: store.overrides.containsKey(dkey(d)) ? const Icon(Icons.swap_horiz, color: cAmber, size: 18) : null,
  );
}

// ================================================================ RECOVERY
class RecoveryScreen extends StatelessWidget {
  const RecoveryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        return ScreenFrame(
          title: 'Recovery',
          subtitle: 'How ready is each muscle',
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _legend('Recovering', cRed),
              _legend('Almost', cAmber),
              _legend('Ready', cGreen),
              _legend('Overdue', cBlue),
            ]),
            const SizedBox(height: 14),
            for (final m in muscles) _muscle(context, m),
            Text(
              'Recovery times are estimates (36-60 hours) adjusted for volume and secondary work. Use them as guidance and override when you feel good.',
              style: TextStyle(color: subtleOf(context), fontSize: 12),
            ),
          ],
        );
      },
    );
  }

  Widget _legend(String t, Color c) => Row(children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);

  Widget _muscle(BuildContext c, String m) {
    final r = store.recovery(m);
    final col = recColor(r);
    final inj = store.injured.contains(m);
    String status;
    if (inj) {
      status = 'Injured: avoided in recommendations';
    } else if (r.overdue) {
      status = 'Overdue: ${r.since} days since last trained';
    } else if (r.pct >= 100) {
      status = r.since == null ? 'Ready, not trained yet' : 'Fully recovered';
    } else {
      status = 'Ready in ${r.hoursLeft.ceil()}h';
    }
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(cap(m), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
          Text('${r.pct.round()}%', style: TextStyle(color: col, fontWeight: FontWeight.w800, fontSize: 17)),
          IconButton(
            tooltip: 'Mark injured',
            icon: Icon(Icons.healing, color: inj ? cRed : subtleOf(c)),
            onPressed: () {
              if (!store.injured.remove(m)) store.injured.add(m);
              store.save();
            },
          ),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(value: r.pct / 100, minHeight: 10, color: col, backgroundColor: fieldOf(c)),
        ),
        const SizedBox(height: 8),
        Text(status, style: TextStyle(color: subtleOf(c), fontSize: 12)),
      ]),
    );
  }
}
