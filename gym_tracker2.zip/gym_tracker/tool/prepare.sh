#!/bin/bash
# Patches the generated Android project: app name, step-counter permission, 120 Hz support.
set -e
cd "$(dirname "$0")/.."
M=android/app/src/main/AndroidManifest.xml
sed -i 's/android:label="[^"]*"/android:label="Gym Tracker"/' "$M"
if ! grep -q ACTIVITY_RECOGNITION "$M"; then
  sed -i 's|<application|<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION"/>\n    <application|' "$M"
fi
find android/app/src/main -name 'MainActivity.*' -delete
D=android/app/src/main/kotlin/com/gymtracker/gym_tracker
mkdir -p "$D"
cat > "$D/MainActivity.kt" <<'KT'
package com.gymtracker.gym_tracker

import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gym/display")
            .setMethodCallHandler { call, result ->
                if (call.method == "setHighRefresh") {
                    val on = call.argument<Boolean>("on") ?: false
                    runOnUiThread {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                val lp = window.attributes
                                if (on) {
                                    @Suppress("DEPRECATION")
                                    val disp = windowManager.defaultDisplay
                                    val cur = disp.mode
                                    var best = cur
                                    for (m in disp.supportedModes) {
                                        if (m.physicalWidth == cur.physicalWidth &&
                                            m.physicalHeight == cur.physicalHeight &&
                                            m.refreshRate > best.refreshRate) {
                                            best = m
                                        }
                                    }
                                    lp.preferredDisplayModeId = best.modeId
                                } else {
                                    lp.preferredDisplayModeId = 0
                                }
                                window.attributes = lp
                            }
                        } catch (e: Exception) {
                        }
                    }
                    result.success(null)
                } else {
                    result.notImplemented()
                }
            }
    }
}
KT
