import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

late Store store;

const weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const muscles = ['chest', 'back', 'shoulders', 'biceps', 'triceps', 'legs', 'abs'];
const recoveryHours = {'chest': 60, 'back': 60, 'legs': 60, 'shoulders': 48, 'biceps': 48, 'triceps': 48, 'abs': 36};

String dkey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
DateTime pdate(String s) {
  final p = s.split('-');
  return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
}

DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);
DateTime mondayOf(DateTime d) => addDays(d, -(d.weekday - 1));
String cap(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
String niceDate(DateTime d) => '${weekdayNames[d.weekday - 1]}, ${d.day} ${monthNames[d.month - 1]}';
String fmt(double v) {
  var s = v.toStringAsFixed(2);
  s = s.replaceFirst(RegExp(r'0+$'), '');
  return s.replaceFirst(RegExp(r'\.$'), '');
}

double e1rm(double w, int r) => r <= 1 ? w : w * (1 + r / 30);

// ---------------------------------------------------------------- models
class Ex {
  String id, name, muscle, tip;
  List<String> sec;
  int sets, repMin, repMax;
  double inc;
  Ex(this.id, this.name, this.muscle, this.sec, this.sets, this.repMin, this.repMax, this.inc, [this.tip = '']);
  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'muscle': muscle, 'sec': sec, 'sets': sets,
        'min': repMin, 'max': repMax, 'inc': inc, 'tip': tip
      };
  factory Ex.fromJson(Map<String, dynamic> j) => Ex(
      j['id'] as String, j['name'] as String, j['muscle'] as String,
      List<String>.from(j['sec'] as List), j['sets'] as int, j['min'] as int,
      j['max'] as int, (j['inc'] as num).toDouble(), (j['tip'] ?? '') as String);
}

class Wk {
  final String id, name;
  final List<String> muscles;
  final int weekday;
  const Wk(this.id, this.name, this.muscles, this.weekday);
}

const workouts = [
  Wk('W1', 'Chest + Triceps', ['chest', 'triceps'], 1),
  Wk('W2', 'Back + Biceps', ['back', 'biceps'], 2),
  Wk('W3', 'Legs + Abs', ['legs', 'abs'], 3),
  Wk('W4', 'Chest + Shoulders', ['chest', 'shoulders'], 4),
  Wk('W5', 'Back + Triceps', ['back', 'triceps'], 5),
  Wk('W6', 'Shoulders + Biceps', ['shoulders', 'biceps'], 6),
];
Wk wkOf(String id) => workouts.firstWhere((w) => w.id == id);
String nameOf(String wid) => wid == 'REST' ? 'Rest day' : wkOf(wid).name;

class SetLog {
  String ex;
  double w;
  int r;
  bool warm;
  SetLog(this.ex, this.w, this.r, [this.warm = false]);
  Map<String, dynamic> toJson() => {'e': ex, 'w': w, 'r': r, 'm': warm};
  factory SetLog.fromJson(Map<String, dynamic> j) =>
      SetLog(j['e'] as String, (j['w'] as num).toDouble(), j['r'] as int, j['m'] == true);
}

class Session {
  final int id, ts, mins;
  final String date, wid;
  final List<SetLog> sets;
  Session(this.id, this.date, this.wid, this.ts, this.mins, this.sets);
  Map<String, dynamic> toJson() =>
      {'id': id, 'date': date, 'wid': wid, 'ts': ts, 'mins': mins, 'sets': sets.map((s) => s.toJson()).toList()};
  factory Session.fromJson(Map<String, dynamic> j) => Session(
      j['id'] as int, j['date'] as String, j['wid'] as String, j['ts'] as int, (j['mins'] as int?) ?? 0,
      (j['sets'] as List).map((e) => SetLog.fromJson(e as Map<String, dynamic>)).toList());
}

class Skip {
  String date, wid, status; // pending | moved | dropped | done | missed
  Skip(this.date, this.wid, this.status);
  Map<String, dynamic> toJson() => {'d': date, 'w': wid, 's': status};
  factory Skip.fromJson(Map<String, dynamic> j) => Skip(j['d'] as String, j['w'] as String, j['s'] as String);
}

class Habit {
  String id, name, desc, created;
  int color, icon, goal;
  final Set<String> checks;
  final Map<String, String> notes;
  Habit({required this.id, required this.name, this.desc = '', required this.color, required this.icon,
      this.goal = 0, required this.created, Set<String>? checks, Map<String, String>? notes})
      : checks = checks ?? <String>{},
        notes = notes ?? <String, String>{};

  bool done(DateTime d) => checks.contains(dkey(d));
  int current(DateTime today) {
    var d = today;
    if (!done(d)) d = addDays(d, -1);
    var n = 0;
    while (done(d)) {
      n++;
      d = addDays(d, -1);
    }
    return n;
  }

  int best() {
    if (checks.isEmpty) return 0;
    final ds = checks.map(pdate).toList()..sort();
    var best = 1, cur = 1;
    for (var i = 1; i < ds.length; i++) {
      cur = addDays(ds[i - 1], 1) == ds[i] ? cur + 1 : 1;
      best = math.max(best, cur);
    }
    return best;
  }

  double rate(DateTime today) {
    var start = pdate(created);
    for (final c in checks) {
      final d = pdate(c);
      if (d.isBefore(start)) start = d;
    }
    final days = math.max(1, today.difference(start).inDays + 1);
    return math.min(100.0, checks.length / days * 100);
  }

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'desc': desc, 'color': color, 'icon': icon, 'goal': goal,
        'created': created, 'checks': checks.toList(), 'notes': notes
      };
  factory Habit.fromJson(Map<String, dynamic> j) => Habit(
      id: j['id'] as String, name: j['name'] as String, desc: (j['desc'] ?? '') as String,
      color: j['color'] as int, icon: j['icon'] as int, goal: (j['goal'] as int?) ?? 0,
      created: j['created'] as String,
      checks: Set<String>.from(j['checks'] as List),
      notes: Map<String, String>.from(j['notes'] as Map));
}

class Rec {
  final double pct, hoursLeft;
  final int? since;
  Rec(this.pct, this.hoursLeft, this.since);
  bool get overdue => since != null && since! >= 7;
}

class Rank {
  final Wk w;
  final double score, avg;
  final String reason;
  final bool pending;
  Rank(this.w, this.score, this.avg, this.reason, this.pending);
}

class Goal {
  final double w;
  final int r;
  final String text, last;
  Goal(this.w, this.r, this.text, this.last);
}

// ---------------------------------------------------------------- defaults
List<Ex> defaultLib() => [
      Ex('bench', 'Barbell Bench Press', 'chest', ['triceps', 'shoulders'], 4, 6, 10, 2.5, 'Shoulder blades pinched, feet planted, bar to mid-chest.'),
      Ex('incdb', 'Incline Dumbbell Press', 'chest', ['shoulders', 'triceps'], 3, 8, 12, 2, 'Bench at 30 degrees, press up and slightly in.'),
      Ex('fly', 'Cable Fly', 'chest', [], 3, 10, 15, 2.5, 'Slight elbow bend, squeeze in the middle.'),
      Ex('pushdown', 'Triceps Pushdown', 'triceps', [], 3, 10, 15, 2.5, 'Elbows pinned to your sides.'),
      Ex('ohtri', 'Overhead Triceps Extension', 'triceps', [], 3, 10, 12, 2.5, 'Keep elbows close to your head.'),
      Ex('latpd', 'Lat Pulldown', 'back', ['biceps'], 4, 8, 12, 2.5, 'Pull to upper chest, lead with the elbows.'),
      Ex('row', 'Barbell Row', 'back', ['biceps'], 4, 6, 10, 2.5, 'Hinge at hips, flat back, pull to lower ribs.'),
      Ex('cablerow', 'Seated Cable Row', 'back', ['biceps'], 3, 10, 12, 2.5, 'Chest up, squeeze shoulder blades.'),
      Ex('bbcurl', 'Barbell Curl', 'biceps', [], 3, 8, 12, 2.5, 'No swinging, full range.'),
      Ex('hammer', 'Hammer Curl', 'biceps', [], 3, 10, 12, 2, 'Neutral grip, elbows still.'),
      Ex('squat', 'Barbell Squat', 'legs', [], 4, 6, 10, 5, 'Brace core, knees track toes, reach parallel.'),
      Ex('legpress', 'Leg Press', 'legs', [], 3, 10, 12, 5, 'Do not lock the knees, controlled full range.'),
      Ex('rdl', 'Romanian Deadlift', 'legs', ['back'], 3, 8, 10, 5, 'Soft knees, hips back, bar close to legs.'),
      Ex('legcurl', 'Leg Curl', 'legs', [], 3, 10, 15, 2.5, 'Slow lowering, hips stay down.'),
      Ex('crunch', 'Cable Crunch', 'abs', [], 3, 12, 15, 2.5, 'Curl the spine, do not just bend at the hips.'),
      Ex('incbb', 'Incline Barbell Press', 'chest', ['shoulders', 'triceps'], 4, 6, 10, 2.5, 'Bench at 30 degrees, bar to upper chest.'),
      Ex('dbpress', 'Dumbbell Shoulder Press', 'shoulders', ['triceps'], 4, 8, 12, 2, 'Ribs down, press straight overhead.'),
      Ex('machchest', 'Machine Chest Press', 'chest', ['triceps'], 3, 10, 12, 2.5, 'Handles at chest height, full stretch.'),
      Ex('lateral', 'Lateral Raise', 'shoulders', [], 3, 12, 15, 1, 'Lead with elbows, stop at shoulder height.'),
      Ex('pecdeck', 'Pec Deck', 'chest', [], 3, 12, 15, 2.5, 'Squeeze and hold for a second.'),
      Ex('tbar', 'T-Bar Row', 'back', ['biceps'], 4, 8, 10, 2.5, 'Flat back, pull to the chest.'),
      Ex('dbrow', 'One-Arm Dumbbell Row', 'back', ['biceps'], 3, 10, 12, 2, 'Pull to the hip, avoid twisting.'),
      Ex('facepull', 'Face Pull', 'back', ['shoulders'], 3, 12, 15, 2.5, 'Pull to forehead, elbows high.'),
      Ex('cgbench', 'Close-Grip Bench Press', 'triceps', ['chest', 'shoulders'], 3, 8, 10, 2.5, 'Hands shoulder-width, elbows tucked.'),
      Ex('skull', 'Skull Crushers', 'triceps', [], 3, 10, 12, 2.5, 'Lower to forehead, upper arms still.'),
      Ex('ohp', 'Overhead Press', 'shoulders', ['triceps'], 4, 6, 10, 2.5, 'Glutes tight, bar path straight up.'),
      Ex('reardelt', 'Rear Delt Fly', 'shoulders', ['back'], 3, 12, 15, 1, 'Slight bend, lead with the elbows.'),
      Ex('incurl', 'Incline Dumbbell Curl', 'biceps', [], 3, 10, 12, 2, 'Let arms hang, full stretch at the bottom.'),
      Ex('preacher', 'Preacher Curl', 'biceps', [], 3, 10, 12, 2.5, 'Keep tension, do not drop fully.'),
    ];

Map<String, List<String>> defaultTemplate() => {
      'W1': ['bench', 'incdb', 'fly', 'pushdown', 'ohtri'],
      'W2': ['latpd', 'row', 'cablerow', 'bbcurl', 'hammer'],
      'W3': ['squat', 'legpress', 'rdl', 'legcurl', 'crunch'],
      'W4': ['incbb', 'dbpress', 'machchest', 'lateral', 'pecdeck'],
      'W5': ['tbar', 'dbrow', 'facepull', 'cgbench', 'skull'],
      'W6': ['ohp', 'lateral', 'reardelt', 'incurl', 'preacher'],
    };

// ---------------------------------------------------------------- store
class Store extends ChangeNotifier {
  final File _file;
  Store._(this._file);

  Map<String, Ex> lib = {};
  Map<String, List<String>> template = {};
  List<Session> sessions = [];
  List<Skip> skips = [];
  Map<String, String> overrides = {};
  List<Map<String, dynamic>> body = [];
  List<Habit> habits = [];
  Set<String> injured = {};
  Map<String, dynamic>? draft;
  String themeMode = 'dark';
  int weeklyGoal = 5;
  int restSecs = 90;
  String startDate = '';

  static Future<Store> load() async {
    final dir = await getApplicationDocumentsDirectory();
    final s = Store._(File('${dir.path}/gym_data.json'));
    if (await s._file.exists()) {
      try {
        s.fromJson(jsonDecode(await s._file.readAsString()) as Map<String, dynamic>);
      } catch (_) {
        try {
          await s._file.copy('${s._file.path}.bak');
        } catch (_) {}
        s.setDefaults();
      }
    } else {
      s.setDefaults();
    }
    s.housekeeping();
    await s.save();
    return s;
  }

  void setDefaults() {
    lib = {for (final e in defaultLib()) e.id: e};
    template = defaultTemplate();
    startDate = dkey(today);
  }

  List _l(dynamic x) => x is List ? x : const [];

  void fromJson(Map<String, dynamic> j) {
    startDate = (j['start'] as String?) ?? dkey(today);
    themeMode = (j['theme'] as String?) ?? 'dark';
    weeklyGoal = (j['goal'] as int?) ?? 5;
    restSecs = (j['rest'] as int?) ?? 90;
    final exs = _l(j['lib']).map((e) => Ex.fromJson(e as Map<String, dynamic>));
    lib = {for (final e in exs) e.id: e};
    if (lib.isEmpty) lib = {for (final e in defaultLib()) e.id: e};
    final tpl = j['tpl'];
    template = tpl is Map
        ? {for (final en in tpl.entries) en.key as String: List<String>.from(en.value as List)}
        : defaultTemplate();
    sessions = _l(j['sessions']).map((e) => Session.fromJson(e as Map<String, dynamic>)).toList()
      ..sort((a, b) => a.ts.compareTo(b.ts));
    skips = _l(j['skips']).map((e) => Skip.fromJson(e as Map<String, dynamic>)).toList();
    overrides = j['over'] is Map ? Map<String, String>.from(j['over'] as Map) : {};
    body = _l(j['body']).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    injured = Set<String>.from(_l(j['injured']));
    habits = _l(j['habits']).map((e) => Habit.fromJson(e as Map<String, dynamic>)).toList();
    draft = j['draft'] is Map ? Map<String, dynamic>.from(j['draft'] as Map) : null;
  }

  Map<String, dynamic> toJson() => {
        'v': 1, 'start': startDate, 'theme': themeMode, 'goal': weeklyGoal, 'rest': restSecs,
        'lib': lib.values.map((e) => e.toJson()).toList(),
        'tpl': template,
        'sessions': sessions.map((e) => e.toJson()).toList(),
        'skips': skips.map((e) => e.toJson()).toList(),
        'over': overrides, 'body': body, 'injured': injured.toList(),
        'habits': habits.map((e) => e.toJson()).toList(),
        'draft': draft,
      };

  Future<void> _last = Future.value();
  Future<void> _write() {
    _last = _last.then((_) async {
      try {
        final tmp = File('${_file.path}.tmp');
        await tmp.writeAsString(jsonEncode(toJson()));
        await tmp.rename(_file.path);
      } catch (_) {}
    });
    return _last;
  }

  Future<void> save() {
    notifyListeners();
    return _write();
  }

  Future<void> saveQuiet() => _write();
  void refresh() {
    housekeeping();
    save();
  }

  String exportJson() => jsonEncode(toJson());
  String? importJson(String text) {
    final backup = toJson();
    try {
      fromJson(jsonDecode(text) as Map<String, dynamic>);
      housekeeping();
      save();
      return null;
    } catch (_) {
      fromJson(backup);
      return 'That is not a valid backup.';
    }
  }

  // ------------------------------------------------------------ dates
  DateTime get today {
    final n = DateTime.now().subtract(const Duration(hours: 4)); // 4 AM day rollover
    return DateTime(n.year, n.month, n.day);
  }

  String get todayKey => dkey(today);

  String baseOf(DateTime d) {
    final w = workouts.where((w) => w.weekday == d.weekday);
    return w.isEmpty ? 'REST' : w.first.id;
  }

  String planned(DateTime d) => overrides[dkey(d)] ?? baseOf(d);

  String dayStatus(DateTime d) {
    final k = dkey(d);
    final t = today;
    if (sessions.any((s) => s.date == k)) return 'done';
    final p = planned(d);
    if (d.isAfter(t)) return p == 'REST' ? 'rest' : (overrides.containsKey(k) ? 'moved' : 'planned');
    if (p == 'REST') return 'rest';
    if (skips.any((s) => s.date == k)) return 'skipped';
    return d == t ? 'today' : 'skipped';
  }

  // ------------------------------------------------------------ pending / skip
  List<Skip> pendingList() =>
      skips.where((s) => s.status == 'pending').toList()..sort((a, b) => a.date.compareTo(b.date));

  void housekeeping() {
    final t = today;
    final start = pdate(startDate);
    for (var i = 1; i <= 7; i++) {
      final d = addDays(t, -i);
      if (d.isBefore(start)) continue;
      final k = dkey(d);
      final p = planned(d);
      if (p == 'REST') continue;
      if (sessions.any((s) => s.date == k && s.wid == p)) continue;
      if (skips.any((s) => s.date == k && s.wid == p)) continue;
      skips.add(Skip(k, p, 'pending'));
    }
    for (final s in skips) {
      if (s.status == 'pending' && pdate(s.date).isBefore(addDays(t, -7))) s.status = 'missed';
    }
    final pend = pendingList();
    while (pend.length > 3) {
      pend.removeAt(0).status = 'missed'; // cap of 3 pending workouts
    }
  }

  /// Returns an error message, or null on success.
  String? skipToday(String mode) {
    final t = today;
    final k = dkey(t);
    final p = planned(t);
    if (p == 'REST') return null;
    switch (mode) {
      case 'rest':
        for (var i = 1; i <= 7; i++) {
          final d = addDays(t, i);
          if (d.weekday == 1) break;
          if (planned(d) == 'REST') {
            overrides[dkey(d)] = p;
            skips.add(Skip(k, p, 'moved'));
            save();
            return null;
          }
        }
        return 'No rest day left this week. Pick another option.';
      case 'shift':
        var carry = p;
        var d = addDays(t, 1);
        while (true) {
          if (d.weekday == 1) {
            skips.add(Skip(dkey(addDays(d, -1)), carry, 'pending'));
            break;
          }
          final cur = planned(d);
          overrides[dkey(d)] = carry;
          if (cur == 'REST') break;
          carry = cur;
          d = addDays(d, 1);
        }
        skips.add(Skip(k, p, 'moved'));
        break;
      case 'swap':
        final tm = addDays(t, 1);
        if (tm.weekday == 1) return 'Tomorrow is a new week. Use another option.';
        final tp = planned(tm);
        overrides[k] = tp;
        overrides[dkey(tm)] = p;
        break;
      case 'pending':
        skips.add(Skip(k, p, 'pending'));
        break;
      case 'drop':
        skips.add(Skip(k, p, 'dropped'));
        break;
    }
    save();
    return null;
  }

  void resetWeek() {
    final mon = mondayOf(today);
    for (var i = 0; i < 7; i++) {
      overrides.remove(dkey(addDays(mon, i)));
    }
    save();
  }

  void dropPending(Skip s) {
    s.status = 'dropped';
    save();
  }

  // ------------------------------------------------------------ recovery
  Rec recovery(String m) {
    final now = DateTime.now();
    double worst = 100, left = 0;
    int? since;
    for (final s in sessions.reversed) {
      final age = now.difference(DateTime.fromMillisecondsSinceEpoch(s.ts)).inMinutes / 60.0;
      int pri = 0, sec = 0;
      for (final x in s.sets) {
        if (x.warm) continue;
        final e = lib[x.ex];
        if (e == null) continue;
        if (e.muscle == m) {
          pri++;
        } else if (e.sec.contains(m)) {
          sec++;
        }
      }
      if (pri > 0 && since == null) since = (age / 24).floor();
      if (age <= 240 && (pri > 0 || sec > 0)) {
        final vol = pri >= 12 ? 1.25 : (pri >= 8 ? 1.1 : 1.0);
        final need = recoveryHours[m]! * (pri > 0 ? vol : 0.5);
        final pct = (age / need * 100).clamp(0, 100).toDouble();
        if (pct < worst) worst = pct;
        if (need - age > left) left = need - age;
      }
      if (since != null && age > 240) break;
    }
    return Rec(worst, left < 0 ? 0 : left, since);
  }

  List<Rank> ranking() {
    final t = today;
    final p = planned(t);
    final doneToday = sessions.any((s) => s.date == todayKey && s.wid == p);
    final skippedToday = skips.any((s) => s.date == todayKey && s.wid == p);
    final pend = pendingList();
    final out = <Rank>[];
    for (final w in workouts) {
      final rs = w.muscles.map((m) => recovery(m).pct).toList();
      final avg = rs.reduce((a, b) => a + b) / rs.length;
      var score = avg;
      final reasons = <String>[];
      final pi = pend.indexWhere((x) => x.wid == w.id);
      if (pi >= 0) {
        final age = t.difference(pdate(pend[pi].date)).inDays;
        score += 15 + math.min(age * 2, 10);
        reasons.add('Pending since ${niceDate(pdate(pend[pi].date))}');
      }
      if (p == w.id && !doneToday && !skippedToday) {
        score += 10;
        reasons.add("Today's plan");
      }
      final low = w.muscles.where((m) => recovery(m).pct < 50).toList();
      if (low.isNotEmpty) {
        score -= 40;
        reasons.add('${cap(low.first)} still recovering');
      }
      if (w.muscles.any(injured.contains)) {
        score -= 100;
        reasons.add('Injury flag');
      }
      if (low.isEmpty && !w.muscles.any(injured.contains)) reasons.add('Muscles ready');
      out.add(Rank(w, score, avg, reasons.join(' · '), pi >= 0));
    }
    out.sort((a, b) {
      final c = b.score.compareTo(a.score);
      if (c != 0) return c;
      return (b.w.id == p ? 1 : 0).compareTo(a.w.id == p ? 1 : 0);
    });
    return out;
  }

  // ------------------------------------------------------------ progression
  Goal goalFor(Ex e) {
    final prev = <List<SetLog>>[];
    for (final s in sessions.reversed) {
      final ws = s.sets.where((x) => x.ex == e.id && !x.warm).toList();
      if (ws.isNotEmpty) prev.add(ws);
      if (prev.length == 2) break;
    }
    if (prev.isEmpty) {
      return Goal(0, e.repMin, 'First time: find a weight you can lift for ${e.repMin}-${e.repMax} reps', 'No history yet');
    }
    final last = prev.first;
    final top = last.map((x) => x.w).reduce(math.max);
    final sets = last.where((x) => x.w == top).toList();
    final minR = sets.map((x) => x.r).reduce(math.min);
    final lastTxt = last.map((x) => '${fmt(x.w)}×${x.r}').join(', ');
    if (minR >= e.repMax && sets.length >= e.sets) {
      final w = top + e.inc;
      return Goal(w, e.repMin, 'Level up: ${fmt(w)} kg × ${e.repMin}', lastTxt);
    }
    if (prev.length == 2) {
      final p2 = prev[1];
      final p2top = p2.map((x) => x.w).reduce(math.max);
      final p2min = p2.where((x) => x.w == p2top).map((x) => x.r).reduce(math.min);
      if (minR < e.repMin && p2min < e.repMin && p2top == top && top > 0) {
        final w = ((top * 0.9) / e.inc).round() * e.inc;
        return Goal(w, e.repMin + 2, 'Stalled twice. Drop to ${fmt(w)} kg and rebuild', lastTxt);
      }
    }
    final r = math.min(e.repMax, minR + 1);
    return Goal(top, r, 'Beat it: ${fmt(top)} kg × $r on every set', lastTxt);
  }

  List<String> finishSession(Session s) {
    final prs = <String>[];
    final byEx = <String, List<SetLog>>{};
    for (final x in s.sets) {
      if (!x.warm) byEx.putIfAbsent(x.ex, () => []).add(x);
    }
    byEx.forEach((id, list) {
      final bestNew = list.map((x) => e1rm(x.w, x.r)).reduce(math.max);
      double bestOld = 0;
      for (final o in sessions) {
        for (final x in o.sets) {
          if (x.ex == id && !x.warm) bestOld = math.max(bestOld, e1rm(x.w, x.r));
        }
      }
      if (bestOld > 0 && bestNew > bestOld + 0.01) {
        prs.add('${lib[id]?.name ?? id}: est. 1RM ${fmt(bestNew)} kg');
      }
    });
    sessions.add(s);
    sessions.sort((a, b) => a.ts.compareTo(b.ts));
    final pend = pendingList();
    final i = pend.indexWhere((p) => p.wid == s.wid);
    if (i >= 0) pend[i].status = 'done';
    draft = null;
    save();
    return prs;
  }

  // ------------------------------------------------------------ stats
  double completion(DateTime from, DateTime to) {
    final start = pdate(startDate);
    final t = today;
    int planned = 0, done = 0;
    for (var d = from; !d.isAfter(to); d = addDays(d, 1)) {
      if (d.isBefore(start) || d.isAfter(t)) continue;
      final k = dkey(d);
      final n = sessions.where((s) => s.date == k).length;
      if (d == t && n == 0) continue;
      if (d.weekday <= 6) planned++;
      done += n;
    }
    if (planned == 0) return 0;
    return math.min(100.0, done / planned * 100);
  }

  int weekCount(DateTime monday) {
    final a = dkey(monday), b = dkey(addDays(monday, 7));
    return sessions.where((s) => s.date.compareTo(a) >= 0 && s.date.compareTo(b) < 0).length;
  }

  (int, int) weekStreaks() {
    final curMon = mondayOf(today);
    var best = 0, run = 0;
    for (var m = mondayOf(pdate(startDate)); !m.isAfter(curMon); m = addDays(m, 7)) {
      if (weekCount(m) >= weeklyGoal) {
        run++;
        best = math.max(best, run);
      } else if (m != curMon) {
        run = 0;
      }
    }
    return (run, best);
  }

  void toggleHabit(Habit h, DateTime d) {
    final k = dkey(d);
    if (!h.checks.remove(k)) h.checks.add(k);
    save();
  }
}
