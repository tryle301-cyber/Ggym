import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'data.dart';
import 'ui.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) => ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Theme', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'system', label: Text('System')),
                    ButtonSegment(value: 'light', label: Text('Light')),
                    ButtonSegment(value: 'dark', label: Text('Dark')),
                  ],
                  selected: {store.themeMode},
                  onSelectionChanged: (s) {
                    store.themeMode = s.first;
                    store.save();
                  },
                ),
              ),
            ]),
          ),
          Panel(
            child: Row(children: [
              const Expanded(child: Text('Weekly workout goal', style: TextStyle(fontWeight: FontWeight.w700))),
              SizedBox(
                width: 140,
                child: NumStepper(
                  value: store.weeklyGoal.toDouble(), step: 1, isInt: true, min: 1,
                  onChanged: (v) {
                    store.weeklyGoal = math.min(7, math.max(1, v.toInt()));
                    store.save();
                  },
                ),
              ),
            ]),
          ),
          Panel(
            child: Row(children: [
              const Expanded(child: Text('Rest timer (seconds)', style: TextStyle(fontWeight: FontWeight.w700))),
              SizedBox(
                width: 140,
                child: NumStepper(
                  value: store.restSecs.toDouble(), step: 15, isInt: true, min: 15,
                  onChanged: (v) {
                    store.restSecs = v.toInt();
                    store.save();
                  },
                ),
              ),
            ]),
          ),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Backup', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Your data lives only on this phone. Copy a backup and paste it somewhere safe (notes, email, Drive).',
                  style: TextStyle(color: subtleOf(context), fontSize: 12)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: FilledButton.tonal(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: store.exportJson()));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup copied to clipboard.')));
                      }
                    },
                    child: const Text('Copy backup'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('Restore from clipboard?'),
                          content: const Text('This replaces all current data with the backup on your clipboard.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Restore')),
                          ],
                        ),
                      );
                      if (ok != true) return;
                      final d = await Clipboard.getData('text/plain');
                      final err = store.importJson(d?.text ?? '');
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err ?? 'Backup restored.')));
                      }
                    },
                    child: const Text('Restore'),
                  ),
                ),
              ]),
            ]),
          ),
          Text('Gym Tracker 1.0 · fully offline · no accounts, no internet permission.',
              style: TextStyle(color: subtleOf(context), fontSize: 12)),
        ]),
      ),
    );
  }
}
