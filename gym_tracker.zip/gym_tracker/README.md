# Gym Tracker (offline)

Fully offline Flutter app: workout logging with progression goals, recovery tracker,
skip/reschedule/pending logic, completion stats, body weight, and a habit tracker.

## Build the APK on GitHub
1. Create a GitHub repo and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the repo > Actions > "Build APK" (it also runs on every push).
3. When it finishes, open the run and download the `gym-tracker-apk` artifact. Unzip it and install `app-release.apk`.

The workflow generates the Android project files itself, so only `lib/`, `pubspec.yaml` and the workflow are needed.
